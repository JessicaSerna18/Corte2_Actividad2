<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/', function () {
    $clientes = Http::get('http://localhost/corte_2_1/public/api/clientes')->json();

    return view('welcome', compact('clientes'));
});

Route::get('/clientes', function () {
    $clientes = Http::get('http://localhost/corte_2_1/public/api/clientes')->json();

    return view('clientes.index', compact('clientes'));
})->name('clientes.index');



Route::get('/clientes/{id}/edit', function ($id) {
    $cliente = Http::get("http://localhost/corte_2_1/public/api/clientes/{$id}")->json();

    return view('clientes.edit', compact('cliente'));
})->name('clientes.edit');

Route::get('/clientes/create', function () {
    return view('clientes.create');
})->name('clientes.create');

Route::get('/clientes/{id}', function ($id) {
    $cliente = Http::get("http://localhost/corte_2_1/public/api/clientes/{$id}")->json();

    return view('clientes.show', compact('cliente'));
})->name('clientes.show');
