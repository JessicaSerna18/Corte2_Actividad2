<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ClienteController extends Controller
{
    public function index()
    {
        //Devuelve todos los registros
        $clientes = Cliente::all();
        return $clientes;
    }

    public function store(Request $request)
    {
        //Guarda el registro
        $request->validate([
            'nombre' => 'required',
            'cedula' => ['required', Rule::unique('clientes', 'cedula')],
            'email' => ['required', 'email', Rule::unique('clientes', 'email')],
        ]);
        //dd($request->all());
        $cliente = new Cliente;
        $cliente->nombre =  $request->nombre;
        $cliente->cedula =  $request->cedula;
        $cliente->email =  $request->email;
        $cliente->save();

        return  $cliente;
    }

    public function show(Cliente $cliente)
    {
        //Devuelve un solo cliente
        return  $cliente;
    }

    public function update(Request $request, Cliente $cliente)
    {
        //Actualiza el registro
        $request->validate([
            'nombre' => 'required',
            'cedula' => ['required', Rule::unique('clientes', 'cedula')],
            'email' => ['required', 'email', Rule::unique('clientes', 'email')],
        ]);

        $cliente->nombre =  $request->nombre;
        $cliente->cedula =  $request->cedula;
        $cliente->email =  $request->email;
        $cliente->update();

        return  $cliente;
    }

   
    public function destroy($id)
    {
        //Elimina 1 Registro
        $cliente = Cliente::find($id);

        if (is_null( $cliente)) {
            return response()->json('No se realizo correctamente la operación', 404);
        }
        
        $cliente->delete();
        return response()->noContent();
    }
}
