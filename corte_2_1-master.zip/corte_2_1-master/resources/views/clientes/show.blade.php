<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Cliente</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <h2>Detalles del Cliente</h2>
        <table class="table">
            <tr>
                <th>Nombre:</th>
                <td>{{ $cliente['nombre'] }}</td>
            </tr>
            <tr>
                <th>Cédula:</th>
                <td>{{ $cliente['cedula'] }}</td>
            </tr>
            <tr>
                <th>Email:</th>
                <td>{{ $cliente['email'] }}</td>
            </tr>
        </table>
        <a href="http://localhost/corte_2_1/public/" class="btn btn-primary">Volver</a>
    </div>
</body>
</html>
