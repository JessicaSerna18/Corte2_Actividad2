<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Clientes</title>
    <!-- Agrega los enlaces a Bootstrap y jQuery -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container " style="margin-top:10%">
        
        <div class="container">
            <h5>Lista de Clientes</h5>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Cédula</th>
                        <th>Email</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($clientes as $cliente)
                    <tr>
                        <td>{{ $cliente['nombre'] }}</td>
                        <td>{{ $cliente['cedula'] }}</td>
                        <td>{{ $cliente['email'] }}</td>
                        <td>
                            <a href="{{ route('clientes.show', $cliente['id']) }}" class="btn btn-info">Ver</a>
                            <a href="{{ route('clientes.edit', $cliente['id']) }}" class="btn btn-warning">Editar</a>
                            <form action="{{ route('clientes.destroy', $cliente['id']) }}" method="POST" style="display: inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            <a href="{{ route('clientes.create') }}" class="btn btn-primary">Crear Cliente</a>
        </div>
        <h5 class="mb-10" style="margin-top:2%">Anderson Serna Estrada - Developer</h5>
        
    </div>

    <script>
        $(document).ready(function () {
            $('form').on('submit', function (e) {
                if (confirm('¿Estás seguro de que deseas eliminar este cliente?')) {
                } else {
                    e.preventDefault();
                }
            });

            $('form').on('submit', function () {
                location.reload(true);
            });
        });

    </script>
</body>
</html>
