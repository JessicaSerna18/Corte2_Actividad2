<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

use Database\Factories\ClienteFactory; 
use App\Models\Cliente;

class ClienteStoreTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_crear_cliente()
    {
        //datos de prueba
        $clienteData = ClienteFactory::new()->make()->toArray();

        //llamar ala api para crear nuevo cliente
        $response = $this->post('/api/clientes', $clienteData);

        // Comprobaciones
        $response->assertStatus(201); //verifica que se haya creado el cliente stutus 201
        //$clienteCreado = Cliente::first(); //cliente creado en la base de datos
        $clienteCreado = Cliente::orderBy('id', 'desc')->first();

        $this->assertEquals($clienteData['nombre'], $clienteCreado->nombre);

    /*  $clienteData = [
        'nombre' => 'peipito peres',
        'cedula' => '123457',
        'email' => 'prueba@pepito.com',
        ];

        $response = $this->post('/api/clientes', $clienteData);

        $response->assertStatus(201); 
        $clienteCreado = Cliente::first(); 

        $this->assertEquals($clienteData['nombre'], $clienteCreado->nombre); */

    }

}
