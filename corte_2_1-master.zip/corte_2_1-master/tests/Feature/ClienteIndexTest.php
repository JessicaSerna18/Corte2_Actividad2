<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use Database\Factories\ClienteFactory; 
use App\Models\Cliente;

class ClienteIndexTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_listar_todos_los_clientes()
    {
        //escenario->crear algunos clientes en la base de datos
        ClienteFactory::new()->count(3)->create();

        //llamar al api para obtener la lista de clientes
        $response = $this->get('/api/clientes');

        // Comprobaciones
        $response->assertStatus(200); //verifica que la respuesta sea status 200
        $clientesEnRespuesta = $response->json();
        //dd($clientesEnRespuesta);
        $this->assertCount(30, $clientesEnRespuesta); //comprueba que se devuelvan los 3 clientes creados
    }

}
