<?php

namespace Tests\Feature;

use App\Models\Cliente;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Database\Factories\ClienteFactory; 

class ObtenerClienteTest extends TestCase
{
    use RefreshDatabase; //trait RefreshDatabase->restaurar la base de datos despues de las pruebas.

    public function test_obtener_cliente_por_id()
    {
        //escenario->Crear un cliente en la base de datos
        $cliente = ClienteFactory::new()->create(); 

        //llamar al api para obtener el cliente por su ID
        $response = $this->get('/api/clientes/' . $cliente->id); // usando el ID del cliente creado

        //Comprobasiones
        $response->assertStatus(200); // Verifica que la respuesta->status 200
        $response->assertJson(['id' => $cliente->id]); // Comprueba que la respuesta contiene el ID del cliente creado siendo un json xd

        //dd($response->content());


        //accedemos al json para ver y validar el nombreClient.
        $clienteEnRespuesta = $response->json(); 
        $this->assertEquals($cliente->nombre, $clienteEnRespuesta['nombre']); // Comprueba que el nombre del cliente en el json ==  nombreClinete -> DB
        //php artisan test tests/Feature/obtenerClienteTest.php
        //ls tests/Feature

    }
}
