<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

use Database\Factories\ClienteFactory; 
use App\Models\Cliente;

class ClienteDestroyTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_eliminar_cliente()
    {
        //escenario->crear un cliente en la base de datos
        $cliente = ClienteFactory::new()->create();

        //llamar al api para eliminar el cliente
        $response = $this->delete('/api/clientes/' . $cliente->id);

        //Comprobaciones
        $response->assertStatus(204); //verifica que el destroy fue status 204
        $clienteEliminado = Cliente::find($cliente->id); //busca clienteID eliminado
        $this->assertNull($clienteEliminado); //if is null 
    }

}
