<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

use Database\Factories\ClienteFactory; 
use App\Models\Cliente;

class ClienteShowTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_obtener_cliente_por_id()
    {
        //escenario->crear un cliente en la base de datos
        $cliente = ClienteFactory::new()->create();

        // Llamar al api para obtener el clienteID
        $response = $this->get('/api/clientes/' . $cliente->id);

        //Comprobaciones
        $response->assertStatus(200); //verifica que la respuesta sea status 200
        //dd($response->content());
        $response->assertJson(['id' => $cliente->id]); //comprueba que la respuesta contiene el clienteID creado
    }

}
