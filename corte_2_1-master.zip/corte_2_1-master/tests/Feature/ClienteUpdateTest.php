<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

use Database\Factories\ClienteFactory; 
use App\Models\Cliente;

class ClienteUpdateTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_actualizar_cliente()
    {
        //escenario->crear un cliente en la base de datos
        $cliente = ClienteFactory::new()->create();

        //datos del update
        $nuevoNombre = 'Preuba XDDDd';
        $datosActualizados = [
            'nombre' => $nuevoNombre,
            'cedula' => $cliente->cedula,
            'email' => $cliente->email,
        ];

        //llamar al api para update clienteID
        $response = $this->put('/api/clientes/' . $cliente->id, $datosActualizados);

        //Comprobaciones
        $response->assertStatus(200); //verifica que el update fue status 200
        $clienteActualizado = Cliente::find($cliente->id); //se obtinecliente actualizado en la base de datos
        $this->assertEquals($nuevoNombre, $clienteActualizado->nombre);
    }

}
